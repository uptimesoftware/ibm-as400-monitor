﻿1)	Copy the jar files in as400.zip into the uptime4/core directory
2)	Copy the XML files into the uptime4/xml directory
3)	Restart the up.time core service
4)	In the uptime4/scripts directory run the following commands
        a.	erdcloader –x xml/MonitorAS400.xml
        b.	erdcloader –x xml/MonitorAS400ptf.xml
5)	This will give you 2 new Advanced Monitors in the Services section of up.time.
6)	Add your AS400 systems to up.time as Nodes and assign the monitors to the systems.
